<?php
$dbuser="root";
$dbpass=" ";
$host="localhost";
$db="PG";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>